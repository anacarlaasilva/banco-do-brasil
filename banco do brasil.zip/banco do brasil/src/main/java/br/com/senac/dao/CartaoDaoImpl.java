/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.senac.dao;

import br.com.senac.entidade.Cartao;
import br.com.senac.entidade.PessoaFisica;
import java.io.Serializable;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;

/**
 *
 * @author ana
 */
public class CartaoDaoImpl extends BaseDaoImpl<Cartao, Long> implements CartaoDao, Serializable { 

    @Override
    public Cartao pesquisarPorId(Long id, Session sessao) throws HibernateException {
        return sessao.find(Cartao.class, id);
    }

 

    @Override
    public List<Cartao> pesquisarPorNome(String nome, Session sessao) throws HibernateException {
        Query<Cartao> consulta = sessao.createQuery("from Cartao c where c.nome like :nome");
        consulta.setParameter("nome", "%" + nome + "%");
        return consulta.getResultList();
        
        
    }

    
}
