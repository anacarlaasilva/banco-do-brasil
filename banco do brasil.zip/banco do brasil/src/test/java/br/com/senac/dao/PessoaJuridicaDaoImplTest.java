/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.senac.dao;

import br.com.senac.entidade.Endereco;
import br.com.senac.entidade.PessoaFisica;
import br.com.senac.entidade.PessoaJuridica;
import static br.com.senac.util.GeradorUtil.gerarCep;
import static br.com.senac.util.GeradorUtil.gerarCidade;
import static br.com.senac.util.GeradorUtil.gerarCnpj;
import static br.com.senac.util.GeradorUtil.gerarLogin;
import static br.com.senac.util.GeradorUtil.gerarNome;
import static br.com.senac.util.GeradorUtil.gerarNumero;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ana.silva100
 */
public class PessoaJuridicaDaoImplTest {

    private PessoaJuridica pessoaJuridica;
    private PessoaJuridicaDao pessoaJuridicaDao;
    private Session sessao;

    public PessoaJuridicaDaoImplTest() {
        pessoaJuridicaDao = new PessoaJuridicaDaoImpl();

    }

    //@Test
    public void testSalvar() {
        System.out.println("salvar");
        pessoaJuridica = new PessoaJuridica("Empresa" + gerarNome(), gerarLogin() + "gmail.com", gerarCnpj(), gerarNumero(6));
        Endereco endereco = gerarEndereco();
        pessoaJuridica.setEndereco(endereco);
        endereco.setCliente(pessoaJuridica);
        sessao = HibernateUtil.abrirConexao();
        pessoaJuridicaDao.salvarOuAlterar(pessoaJuridica, sessao);
        sessao.close();
        assertNotNull(pessoaJuridica.getId());

    }
    
      private Endereco gerarEndereco(){
        Endereco end = new Endereco("Rua das Flores", 
                "Centro", 
                gerarNumero(3),
                gerarCidade(),
                "SC",
                  "casa",
                gerarCep());
        return end;
        
    }

    //@Test
    public void testAlterar() {
        System.out.println("alterar");
        buscarPessoaJuridicaBd();
        pessoaJuridica.setNome(gerarNome());
        pessoaJuridica.setCnpj(gerarCnpj());        
        pessoaJuridica.getEndereco().setLogradouro("Rua nova");
        sessao = HibernateUtil.abrirConexao();
        pessoaJuridicaDao.salvarOuAlterar(pessoaJuridica, sessao);
        sessao.close();

        sessao = HibernateUtil.abrirConexao();
        PessoaJuridica pesJuridicaAlt = pessoaJuridicaDao.pesquisarPorId(pessoaJuridica.getId(), sessao);
        sessao.close();
        assertEquals(pessoaJuridica.getNome(), pesJuridicaAlt.getNome());
        assertEquals(pessoaJuridica.getCnpj(), pesJuridicaAlt.getCnpj());
        assertEquals(pessoaJuridica.getEndereco().getLogradouro(), pesJuridicaAlt.getEndereco().getLogradouro());
        
    }

    
    public void testExcluir() {
        System.out.println("excluir");
        buscarPessoaJuridicaBd();
        pessoaJuridicaDao.excluir(pessoaJuridica, sessao);
       sessao = HibernateUtil.abrirConexao();
        PessoaJuridica pesJuridicaExc = pessoaJuridicaDao.pesquisarPorId(pessoaJuridica.getId(), sessao);
        sessao.close();
        assertNull(pesJuridicaExc);
        
    }
    
     //@Test
    public void testPesquisarPorNome() {
        System.out.println("pesquisarPorNome");
        buscarPessoaJuridicaBd();
        sessao = HibernateUtil.abrirConexao();
        List<PessoaJuridica> juridicas = pessoaJuridicaDao.pesquisarPorNome(pessoaJuridica.getNome(),sessao);
        sessao.close();
        assertTrue(!juridicas.isEmpty());
    }
    
    //@Test
    public void testPesquisarPorId() {
        System.out.println("pesquisarPorId");
        buscarPessoaJuridicaBd();
        sessao = HibernateUtil.abrirConexao();
        PessoaJuridica pesJuridica = pessoaJuridicaDao.pesquisarPorId(pessoaJuridica.getId(), sessao);
        sessao.close();
        assertNotNull(pesJuridica);

        

    }

    private PessoaJuridica buscarPessoaJuridicaBd() {
        String hql = "from PessoaJuridica pj ";
        sessao = HibernateUtil.abrirConexao();
        Query<PessoaJuridica> consulta = sessao.createQuery(hql);
        List<PessoaJuridica> pessoaJuridicas = consulta.getResultList();
        sessao.close();

        if (pessoaJuridicas.isEmpty()) {
            testSalvar();
        } else {
            pessoaJuridica = pessoaJuridicas.get(0);
        }
        return pessoaJuridica;

    }

}
