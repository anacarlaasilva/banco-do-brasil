/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.senac.dao;

import br.com.senac.entidade.Cartao;
import br.com.senac.entidade.PessoaJuridica;
import static br.com.senac.util.GeradorUtil.gerarBandeira;
import static br.com.senac.util.GeradorUtil.gerarNumero;
import static br.com.senac.util.GeradorUtil.gerarValidade;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ana
 */
public class CartaoDaoImplTest {
    
    private Cartao cartao; 
    
    private CartaoDao cartaoDao;
    
    private Session sessao;
    
    public CartaoDaoImplTest() {
        cartaoDao = new CartaoDaoImpl();
        
        
        
    }

    //@Test
    public void testSalvar() {
        System.out.println("salvar");
        buscarCartaoBd(); 
       cartao = cartao(gerarNumero(0) , gerarBandeira(),gerarValidade());
       sessao = HibernateUtil.abrirConexao();
       cartaoDao.salvarOuAlterar(cartao, sessao);
       sessao.close();
       assertNotNull(cartao.getId());

    }
    //@Test
    public void testAlterar() {
        System.out.println("alterar");
        buscarCartaoBd(); 
        cartao.setNumero(gerarNumero());
        cartao.setBandeira(gerarBandeira());
        cartao.setValidadeano(gerarValidade());
       sessao = HibernateUtil.abrirConexao();
       cartaoDao.salvarOuAlterar(cartao, sessao);
       sessao.close();
       assertNotNull(cartao.getId());

    }
    
    
   // @Test
    public void testPesquisarPorId() {
        System.out.println("pesquisarPorId");
       buscarCartaoBd();
        sessao = HibernateUtil.abrirConexao();
       cartao  = cartaoDao.pesquisarPorId(cartao.getId(), sessao);
        sessao.close();
        assertNotNull(cartao);

    }

   
    
    //@Test
    public void testPesquisarPorNome() {
        System.out.println("pesquisarPorNome");
       
    }

    private Cartao buscarCartaoBd() {
        String hql = "from cartao c ";
        sessao = HibernateUtil.abrirConexao();
        Query<Cartao> consulta = sessao.createQuery(hql);
        List<Cartao> cartoes = consulta.getResultList();
        sessao.close();
        
        if(cartoes.isEmpty()){
            testSalvar();
            
        }else{
            cartao = cartoes.get(0);
 

    }
    return cartao;
    
}

    private Cartao cartao(String gerarNumero, String gerarBandeira, String gerarValidade) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
